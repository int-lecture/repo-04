<?php

## CONFIG ##

# LIST EMAIL ADDRESS
$recipient = "list.txt";

# SUBJECT (Subscribe/Remove)
$subject = "Newsletter registrieren";

# RESULT PAGE
$location = "http://jonathan.sv.hs-mannheim.de/~d.capuana/";

## FORM VALUES ##


$sender = "http://jonathan.sv.hs-mannheim.de/~d.capuana/produkt.html";

# MAIL BODY
$body .= "Vorname: ".$_REQUEST['Vorname']." \n";
$body .= "Nachname: ".$_REQUEST['Nachname']." \n";
$body .= "Email: ".$_REQUEST['Email']." \n";
# add more fields here if required

## SEND MESSGAE ##

mail( $recipient, $subject, $body, "From: $sender" ) or die ("Mail could not be sent.");

## SHOW RESULT PAGE ##

header( "Location: $location" );
?>